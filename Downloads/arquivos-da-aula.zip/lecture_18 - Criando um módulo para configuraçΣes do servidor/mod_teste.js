module.exports = function(){
    var msg = "Este modulo contem apenas uma string";
    return msg;
}